package com.rdrg.back.dto.request.payment;

import com.rdrg.back.entity.DeviceRentStatusEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PatchRentStatusResponseDto {
    private String rentStatus;

    private PatchRentStatusResponseDto (DeviceRentStatusEntity deviceRentStatusEntity) {
        this.rentStatus = deviceRentStatusEntity.getRentStatus();
    }
}
